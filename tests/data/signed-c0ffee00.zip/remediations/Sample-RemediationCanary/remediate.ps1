﻿<#
.SYNOPSIS
  Remediation: write the SecTechTalk remediation canary value.
.DESCRIPTION
  Harmless pipeline test. Creates HKLM:\SOFTWARE\SecTechTalk\RemediationCanary with Version=1 and a timestamp.
  Touches nothing else. Exit 0 = success, 1 = failure.
#>
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$KeyPath = 'HKLM:\SOFTWARE\SecTechTalk\RemediationCanary'
try {
    if ($PSVersionTable.PSVersion.Major -lt 5) { Write-Output "FAIL prereq: PowerShell 5.1+ required"; exit 1 }
    if (-not (Test-Path -Path $KeyPath)) { New-Item -Path $KeyPath -Force | Out-Null }
    New-ItemProperty -Path $KeyPath -Name Version -Value '1' -PropertyType String -Force | Out-Null
    New-ItemProperty -Path $KeyPath -Name LastRemediatedUtc -Value ([DateTime]::UtcNow.ToString('o')) -PropertyType String -Force | Out-Null
    Write-Output "Remediated: canary Version=1"
    exit 0
} catch {
    Write-Output "Remediation error: $($_.Exception.Message)"
    exit 1
}

# SIG # Begin signature block
# VGVzdCBmaXh0dXJlLCBub3QgYSByZWFsIHNpZ25hdHVyZQ==
# SIG # End signature block
