﻿<#
.SYNOPSIS
  Detection: is the SecTechTalk remediation canary value present?
.DESCRIPTION
  Harmless pipeline test. Reads HKLM:\SOFTWARE\SecTechTalk\RemediationCanary\Version.
  Exit 0 = compliant (no remediation). Exit 1 = not compliant (Intune runs remediate.ps1).
  Prereqs: Windows PowerShell 5.1+ on the device, runs as SYSTEM (registry under HKLM).
#>
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$KeyPath = 'HKLM:\SOFTWARE\SecTechTalk\RemediationCanary'
$Expected = '1'
try {
    if ($PSVersionTable.PSVersion.Major -lt 5) { Write-Output "FAIL prereq: PowerShell 5.1+ required, found $($PSVersionTable.PSVersion)"; exit 1 }
    $value = (Get-ItemProperty -Path $KeyPath -Name Version -ErrorAction SilentlyContinue).Version
    if ($value -eq $Expected) { Write-Output "Compliant: canary Version=$value"; exit 0 }
    Write-Output "Not compliant: canary Version='$value', expected '$Expected'"
    exit 1
} catch {
    Write-Output "Detection error: $($_.Exception.Message)"
    exit 1
}

# SIG # Begin signature block
# VGVzdCBmaXh0dXJlLCBub3QgYSByZWFsIHNpZ25hdHVyZQ==
# SIG # End signature block
